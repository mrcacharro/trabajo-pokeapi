document.addEventListener('DOMContentLoaded', () => {
    fetchGalarPokemon();
});

function fetchGalarPokemon() {
    const galarPokemon = [
        { name: "Grookey", id: 810 },
        { name: "Scorbunny", id: 813 },
        { name: "Sobble", id: 816 },
        { name: "Wooloo", id: 831 },
        { name: "Corviknight", id: 823 },
    ];

    const container = document.getElementById('pokemon-list');

    galarPokemon.forEach(pokemon => {
        const pokemonCard = document.createElement('div');
        pokemonCard.classList.add('pokemon-card');

        const pokemonImage = document.createElement('img');
        pokemonImage.src = `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/${pokemon.id}.png`;
        pokemonImage.alt = pokemon.name;

        const pokemonName = document.createElement('p');
        pokemonName.textContent = pokemon.name;

        pokemonCard.appendChild(pokemonImage);
        pokemonCard.appendChild(pokemonName);
        container.appendChild(pokemonCard);
    });
}