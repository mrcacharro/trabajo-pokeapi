document.addEventListener('DOMContentLoaded', () => {
    const pokemonGrid = document.getElementById('pokemon-grid');
    const detailsPanel = document.getElementById('details-panel');
    const closeBtn = document.getElementById('close-btn');
    const leftArrow = document.getElementById('left-arrow');
    const rightArrow = document.getElementById('right-arrow');
    const pokemonNameElem = document.getElementById('pokemon-name');
    const pokemonDescriptionElem = document.getElementById('pokemon-description');
    const pokemonTypeElem = document.getElementById('pokemon-type'); // Referencia al nuevo elemento
    const pokemonImageSmall = document.getElementById('pokemon-image-small');
    const pokemonImageMain = document.getElementById('pokemon-image-main');
    const extraImagesContainer = document.getElementById('extra-images-container');
    const paginationIndicator = document.getElementById('pagination-indicator');
    const typeFilter = document.getElementById('type-filter');
    const searchBar = document.getElementById('search-bar');

    let currentBox = 1;
    let pokemonData = [];
    let filteredPokemonData = [];

    const typeTranslations = {
        normal: 'Normal',
        fire: 'Fuego',
        water: 'Agua',
        electric: 'Eléctrico',
        grass: 'Planta',
        ice: 'Hielo',
        fighting: 'Lucha',
        poison: 'Veneno',
        ground: 'Tierra',
        flying: 'Volador',
        psychic: 'Psíquico',
        bug: 'Bicho',
        rock: 'Roca',
        ghost: 'Fantasma',
        dragon: 'Dragón',
        dark: 'Siniestro',
        steel: 'Acero',
        fairy: 'Hada'
    };

    const typeColors = {
        normal: '#A8A878',
        fire: '#F08030',
        water: '#6890F0',
        electric: '#F8D030',
        grass: '#78C850',
        ice: '#98D8D8',
        fighting: '#C03028',
        poison: '#A040A0',
        ground: '#E0C068',
        flying: '#A890F0',
        psychic: '#F85888',
        bug: '#A8B820',
        rock: '#B8A038',
        ghost: '#705898',
        dragon: '#7038F8',
        dark: '#705848',
        steel: '#B8B8D0',
        fairy: '#EE99AC'
    };

    async function getPokemonData(pokemonId) {
        try {
            const response = await fetch(`https://pokeapi.co/api/v2/pokemon/${pokemonId}`);
            const pokemon = await response.json();

            const speciesResponse = await fetch(pokemon.species.url);
            const species = await speciesResponse.json();

            const descriptionEntry = species.flavor_text_entries.find(entry => entry.language.name === 'es' && entry.version.name === 'sword');

            const images = [
                pokemon.sprites.front_default,
                pokemon.sprites.other['official-artwork'].front_default
            ];

            return {
                name: pokemon.name,
                types: pokemon.types.map(typeInfo => typeInfo.type.name),
                description: descriptionEntry ? descriptionEntry.flavor_text : 'Descripción no disponible',
                images: images
            };
        } catch (error) {
            console.error('Error fetching Pokémon data:', error);
            return null; // or handle error as needed
        }
    }

    async function loadGalarPokemonData() {
        const promises = [];
        for (let i = 810; i <= 898; i++) {
            promises.push(getPokemonData(i));
        }
        const results = await Promise.all(promises);

        const boxes = [];
        while (results.length) {
            boxes.push(results.splice(0, 96));
        }
        pokemonData = boxes;
        filteredPokemonData = boxes;

        loadBox(currentBox);
    }

    function loadBox(boxNumber) {
        pokemonGrid.innerHTML = '';
        const boxData = filteredPokemonData[boxNumber - 1] || [];
        boxData.forEach(pokemon => {
            const box = document.createElement('div');
            box.classList.add('pokemon-box', `type-${pokemon.types[0]}`);
            box.setAttribute('data-pokemon', pokemon.name);
            box.setAttribute('data-description', pokemon.description);
            box.setAttribute('data-images', pokemon.images.join(','));

            const img = document.createElement('img');
            img.src = pokemon.images[0];
            img.alt = pokemon.name;
            box.appendChild(img);

            const nameLabel = document.createElement('span');
            nameLabel.classList.add('name-label');
            nameLabel.textContent = pokemon.name;
            box.appendChild(nameLabel);

            const typeLabel = document.createElement('span');
            typeLabel.classList.add('type-label');
            const translatedTypes = pokemon.types.map(type => typeTranslations[type] || type);
            typeLabel.textContent = translatedTypes.join(', ');
            typeLabel.style.color = typeColors[pokemon.types[0]]; // Color del primer tipo
            box.appendChild(typeLabel);

            pokemonGrid.appendChild(box);

            box.addEventListener('click', () => {
                pokemonNameElem.textContent = pokemon.name;
                pokemonDescriptionElem.textContent = pokemon.description;
                const translatedTypes = pokemon.types.map(type => typeTranslations[type] || type);
                const typeElements = translatedTypes.map((type, index) => {
                    const typeElem = document.createElement('span');
                    typeElem.textContent = type;
                    typeElem.style.color = typeColors[pokemon.types[index]];
                    return typeElem;
                });
                pokemonTypeElem.innerHTML = 'Tipo: ';
                typeElements.forEach(typeElem => pokemonTypeElem.appendChild(typeElem));
                pokemonImageMain.src = pokemon.images[1];
                pokemonImageSmall.src = pokemon.images[0];

                extraImagesContainer.innerHTML = '';

                detailsPanel.style.display = 'block';
            });
        });

        paginationIndicator.textContent = `${boxNumber}/${filteredPokemonData.length}`;
    }

    function filterPokemonByType(boxData) {
        const selectedType = typeFilter.value;
        if (selectedType === 'all') {
            return boxData;
        }
        return boxData.filter(pokemon => pokemon.types.includes(selectedType));
    }

    function searchPokemonByName(boxData, searchText) {
        return boxData.filter(pokemon => pokemon.name.toLowerCase().includes(searchText.toLowerCase()));
    }

    function applyFilters() {
        const selectedType = typeFilter.value;
        const searchText = searchBar.value;

        filteredPokemonData = pokemonData.map(box => {
            let filteredBox = filterPokemonByType(box);
            if (searchText) {
                filteredBox = searchPokemonByName(filteredBox, searchText);
            }
            return filteredBox;
        }).filter(box => box.length > 0);

        currentBox = 1;
        loadBox(currentBox);
    }

    closeBtn.addEventListener('click', () => {
        detailsPanel.style.display = 'none';
    });

    leftArrow.addEventListener('click', () => {
        if (currentBox > 1) {
            currentBox--;
            loadBox(currentBox);
        }
    });

    rightArrow.addEventListener('click', () => {
        if (currentBox < filteredPokemonData.length) {
            currentBox++;
            loadBox(currentBox);
        }
    });

    typeFilter.addEventListener('change', () => {
        applyFilters();
    });

    searchBar.addEventListener('input', () => {
        applyFilters();
    });

    loadGalarPokemonData();
});