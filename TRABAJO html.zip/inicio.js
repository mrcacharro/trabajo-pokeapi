function changeContent(title, text, imageUrl) {
    document.getElementById('content-title').innerText = title;
    document.getElementById('content-text').innerText = text;
    const contentImage = document.getElementById('content-image');
    if (imageUrl) {
        contentImage.src = imageUrl;
        contentImage.style.display = 'block';
    } else {
        contentImage.style.display = 'none';
    }
}
