function handleIconClick(url) {
    window.location.href = url;
}