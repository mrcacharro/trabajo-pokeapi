document.addEventListener('DOMContentLoaded', () => {
    const pokemonGrid = document.getElementById('pokemon-grid');
    const detailsPanel = document.getElementById('details-panel');
    const closeBtn = document.getElementById('close-btn');
    const leftArrow = document.getElementById('left-arrow');
    const rightArrow = document.getElementById('right-arrow');
    const pokemonNameElem = document.getElementById('pokemon-name');
    const pokemonDescriptionElem = document.getElementById('pokemon-description');
    const pokemonImageSmall = document.getElementById('pokemon-image-small');
    const pokemonImageMain = document.getElementById('pokemon-image-main');
    const extraImagesContainer = document.getElementById('extra-images-container');
    const paginationIndicator = document.getElementById('pagination-indicator');

    let currentBox = 1;
    let pokemonData = [];

    const shinyImages = {
        grookey: [
            'https://www.serebii.net/swordshield/pokemon/810.png',
            'https://www.serebii.net/Shiny/SWSH/810.png'
        ],
        scorbunny: [
            'https://www.serebii.net/swordshield/pokemon/813.png',
            'https://www.serebii.net/Shiny/SWSH/813.png'
        ],
        sobble: [
            'https://www.serebii.net/swordshield/pokemon/816.png',
            'https://www.serebii.net/Shiny/SWSH/816.png'
        ],
        thwackey: [
            'https://www.serebii.net/swordshield/pokemon/811.png',
            'https://www.serebii.net/Shiny/SWSH/811.png'
        ],
        rillaboom: [
            'https://www.serebii.net/swordshield/pokemon/812.png',
            'https://www.serebii.net/Shiny/SWSH/812.png'
        ],
        raboot: [
            'https://www.serebii.net/swordshield/pokemon/814.png',
            'https://www.serebii.net/Shiny/SWSH/814.png'
        ],
        cinderace: [
            'https://www.serebii.net/swordshield/pokemon/815.png',
            'https://www.serebii.net/Shiny/SWSH/815.png'
        ],
        drizzile: [
            'https://www.serebii.net/swordshield/pokemon/817.png',
            'https://www.serebii.net/Shiny/SWSH/817.png'
        ],
        inteleon: [
            'https://www.serebii.net/swordshield/pokemon/818.png',
            'https://www.serebii.net/Shiny/SWSH/818.png'
        ],
        skwovet: [
            'https://www.serebii.net/swordshield/pokemon/819.png',
            'https://www.serebii.net/Shiny/SWSH/819.png'
        ],
        greedent: [
            'https://www.serebii.net/swordshield/pokemon/820.png',
            'https://www.serebii.net/Shiny/SWSH/820.png'
        ],
        rookidee: [
            'https://www.serebii.net/swordshield/pokemon/821.png',
            'https://www.serebii.net/Shiny/SWSH/821.png'
        ],
        corvisquire: [
            'https://www.serebii.net/swordshield/pokemon/822.png',
            'https://www.serebii.net/Shiny/SWSH/822.png'
        ],
        corviknight: [
            'https://www.serebii.net/swordshield/pokemon/823.png',
            'https://www.serebii.net/Shiny/SWSH/823.png'
        ],
        blipbug: [
            'https://www.serebii.net/swordshield/pokemon/824.png',
            'https://www.serebii.net/Shiny/SWSH/824.png'
        ],
        dottler: [
            'https://www.serebii.net/swordshield/pokemon/825.png',
            'https://www.serebii.net/Shiny/SWSH/825.png'
        ],
        orbeetle: [
            'https://www.serebii.net/swordshield/pokemon/826.png',
            'https://www.serebii.net/Shiny/SWSH/826.png'
        ],
        nickit: [
            'https://www.serebii.net/swordshield/pokemon/827.png',
            'https://www.serebii.net/Shiny/SWSH/827.png'
        ],
        thievul: [
            'https://www.serebii.net/swordshield/pokemon/828.png',
            'https://www.serebii.net/Shiny/SWSH/828.png'
        ],
        gossifleur: [
            'https://www.serebii.net/swordshield/pokemon/829.png',
            'https://www.serebii.net/Shiny/SWSH/829.png'
        ],
        eldegoss: [
            'https://www.serebii.net/swordshield/pokemon/830.png',
            'https://www.serebii.net/Shiny/SWSH/830.png'
        ],
        wooloo: [
            'https://www.serebii.net/swordshield/pokemon/831.png',
            'https://www.serebii.net/Shiny/SWSH/831.png'
        ],
        dubwool: [
            'https://www.serebii.net/swordshield/pokemon/832.png',
            'https://www.serebii.net/Shiny/SWSH/832.png'
        ],
        chewtle: [
            'https://www.serebii.net/swordshield/pokemon/833.png',
            'https://www.serebii.net/Shiny/SWSH/833.png'
        ],
        drednaw: [
            'https://www.serebii.net/swordshield/pokemon/834.png',
            'https://www.serebii.net/Shiny/SWSH/834.png'
        ],
        yamper: [
            'https://www.serebii.net/swordshield/pokemon/835.png',
            'https://www.serebii.net/Shiny/SWSH/835.png'
        ],
        boltund: [
            'https://www.serebii.net/swordshield/pokemon/836.png',
            'https://www.serebii.net/Shiny/SWSH/836.png'
        ],
        rolycoly: [
            'https://www.serebii.net/swordshield/pokemon/837.png',
            'https://www.serebii.net/Shiny/SWSH/837.png'
        ],
        carkol: [
            'https://www.serebii.net/swordshield/pokemon/838.png',
            'https://www.serebii.net/Shiny/SWSH/838.png'
        ],
        coalossal: [
            'https://www.serebii.net/swordshield/pokemon/839.png',
            'https://www.serebii.net/Shiny/SWSH/839.png'
        ],
        applin: [
            'https://www.serebii.net/swordshield/pokemon/840.png',
            'https://www.serebii.net/Shiny/SWSH/840.png'
        ],
        flapple: [
            'https://www.serebii.net/swordshield/pokemon/841.png',
            'https://www.serebii.net/Shiny/SWSH/841.png'
        ],
        appletun: [
            'https://www.serebii.net/swordshield/pokemon/842.png',
            'https://www.serebii.net/Shiny/SWSH/842.png'
        ],
        silicobra: [
            'https://www.serebii.net/swordshield/pokemon/843.png',
            'https://www.serebii.net/Shiny/SWSH/843.png'
        ],
        sandaconda: [
            'https://www.serebii.net/swordshield/pokemon/844.png',
            'https://www.serebii.net/Shiny/SWSH/844.png'
        ],
        cramorant: [
            'https://www.serebii.net/swordshield/pokemon/845.png',
            'https://www.serebii.net/Shiny/SWSH/845.png'
        ],
        arrokuda: [
            'https://www.serebii.net/swordshield/pokemon/846.png',
            'https://www.serebii.net/Shiny/SWSH/846.png'
        ],
        barraskewda: [
            'https://www.serebii.net/swordshield/pokemon/847.png',
            'https://www.serebii.net/Shiny/SWSH/847.png'
        ],
        toxel: [
            'https://www.serebii.net/swordshield/pokemon/848.png',
            'https://www.serebii.net/Shiny/SWSH/848.png'
        ],
        toxtricity_amped: [
            'https://www.serebii.net/swordshield/pokemon/849.png',
            'https://www.serebii.net/Shiny/SWSH/849.png'
        ],
        sizzlipede: [
            'https://www.serebii.net/swordshield/pokemon/850.png',
            'https://www.serebii.net/Shiny/SWSH/850.png'
        ],
        centiskorch: [
            'https://www.serebii.net/swordshield/pokemon/851.png',
            'https://www.serebii.net/Shiny/SWSH/851.png'
        ],
        clobbopus: [
            'https://www.serebii.net/swordshield/pokemon/852.png',
            'https://www.serebii.net/Shiny/SWSH/852.png'
        ],
        grapploct: [
            'https://www.serebii.net/swordshield/pokemon/853.png',
            'https://www.serebii.net/Shiny/SWSH/853.png'
        ],
        sinistea: [
            'https://www.serebii.net/swordshield/pokemon/854.png',
            'https://www.serebii.net/Shiny/SWSH/854.png'
        ],
        polteageist: [
            'https://www.serebii.net/swordshield/pokemon/855.png',
            'https://www.serebii.net/Shiny/SWSH/855.png'
        ],
        hatenna: [
            'https://www.serebii.net/swordshield/pokemon/856.png',
            'https://www.serebii.net/Shiny/SWSH/856.png'
        ],
        hattrem: [
            'https://www.serebii.net/swordshield/pokemon/857.png',
            'https://www.serebii.net/Shiny/SWSH/857.png'
        ],
        hatterene: [
            'https://www.serebii.net/swordshield/pokemon/858.png',
            'https://www.serebii.net/Shiny/SWSH/858.png'
        ],
        impidimp: [
            'https://www.serebii.net/swordshield/pokemon/859.png',
            'https://www.serebii.net/Shiny/SWSH/859.png'
        ],
        morgrem: [
            'https://www.serebii.net/swordshield/pokemon/860.png',
            'https://www.serebii.net/Shiny/SWSH/860.png'
        ],
        grimmsnarl: [
            'https://www.serebii.net/swordshield/pokemon/861.png',
            'https://www.serebii.net/Shiny/SWSH/861.png'
        ],
        obstagoon: [
            'https://www.serebii.net/swordshield/pokemon/862.png',
            'https://www.serebii.net/Shiny/SWSH/862.png'
        ],
        perrserker: [
            'https://www.serebii.net/swordshield/pokemon/863.png',
            'https://www.serebii.net/Shiny/SWSH/863.png'
        ],
        cursola: [
            'https://www.serebii.net/swordshield/pokemon/864.png',
            'https://www.serebii.net/Shiny/SWSH/864.png'
        ],
        sirfetchd: [
            'https://www.serebii.net/swordshield/pokemon/865.png',
            'https://www.serebii.net/Shiny/SWSH/865.png'
        ],
        mr_rime: [
            'https://www.serebii.net/swordshield/pokemon/866.png',
            'https://www.serebii.net/Shiny/SWSH/866.png'
        ],
        runerigus: [
            'https://www.serebii.net/swordshield/pokemon/867.png',
            'https://www.serebii.net/Shiny/SWSH/867.png'
        ],
        milcery: [
            'https://www.serebii.net/swordshield/pokemon/868.png',
            'https://www.serebii.net/Shiny/SWSH/868.png'
        ],
        alcremie: [
            'https://www.serebii.net/swordshield/pokemon/869.png',
            'https://www.serebii.net/Shiny/SWSH/869.png'
        ],
        falinks: [
            'https://www.serebii.net/swordshield/pokemon/870.png',
            'https://www.serebii.net/Shiny/SWSH/870.png'
        ],
        pincurchin: [
            'https://www.serebii.net/swordshield/pokemon/871.png',
            'https://www.serebii.net/Shiny/SWSH/871.png'
        ],
        snom: [
            'https://www.serebii.net/swordshield/pokemon/872.png',
            'https://www.serebii.net/Shiny/SWSH/872.png'
        ],
        frosmoth: [
            'https://www.serebii.net/swordshield/pokemon/873.png',
            'https://www.serebii.net/Shiny/SWSH/873.png'
        ],
        stonjourner: [
            'https://www.serebii.net/swordshield/pokemon/874.png',
            'https://www.serebii.net/Shiny/SWSH/874.png'
        ],
        eiscue: [
            'https://www.serebii.net/swordshield/pokemon/875.png',
            'https://www.serebii.net/Shiny/SWSH/875.png'
        ],
        indeedee: [
            'https://www.serebii.net/swordshield/pokemon/876.png',
            'https://www.serebii.net/Shiny/SWSH/876.png'
        ],
        indeedee: [
            'https://www.serebii.net/swordshield/pokemon/876.png',
            'https://www.serebii.net/Shiny/SWSH/876.png'
        ],
        morpeko: [
            'https://www.serebii.net/swordshield/pokemon/877.png',
            'https://www.serebii.net/Shiny/SWSH/877.png'
        ],
        cufant: [
            'https://www.serebii.net/swordshield/pokemon/878.png',
            'https://www.serebii.net/Shiny/SWSH/878.png'
        ],
        copperajah: [
            'https://www.serebii.net/swordshield/pokemon/879.png',
            'https://www.serebii.net/Shiny/SWSH/879.png'
        ],
        dracozolt: [
            'https://www.serebii.net/swordshield/pokemon/880.png',
            'https://www.serebii.net/Shiny/SWSH/880.png'
        ],
        arctozolt: [
            'https://www.serebii.net/swordshield/pokemon/881.png',
            'https://www.serebii.net/Shiny/SWSH/881.png'
        ],
        dracovish: [
            'https://www.serebii.net/swordshield/pokemon/882.png',
            'https://www.serebii.net/Shiny/SWSH/882.png'
        ],
        arctovish: [
            'https://www.serebii.net/swordshield/pokemon/883.png',
            'https://www.serebii.net/Shiny/SWSH/883.png'
        ],
        duraludon: [
            'https://www.serebii.net/swordshield/pokemon/884.png',
            'https://www.serebii.net/Shiny/SWSH/884.png'
        ],
        dreepy: [
            'https://www.serebii.net/swordshield/pokemon/885.png',
            'https://www.serebii.net/Shiny/SWSH/885.png'
        ],
        drakloak: [
            'https://www.serebii.net/swordshield/pokemon/886.png',
            'https://www.serebii.net/Shiny/SWSH/886.png'
        ],
        dragapult: [
            'https://www.serebii.net/swordshield/pokemon/887.png',
            'https://www.serebii.net/Shiny/SWSH/887.png'
        ],
        zacian: [
            'https://www.serebii.net/swordshield/pokemon/888.png',
            'https://www.serebii.net/Shiny/SWSH/888.png'
        ],
        zamazenta: [
            'https://www.serebii.net/swordshield/pokemon/889.png',
            'https://www.serebii.net/Shiny/SWSH/889.png'
        ],
        eternatus: [
            'https://www.serebii.net/swordshield/pokemon/890.png',
            'https://www.serebii.net/Shiny/SWSH/890.png'
        ],
        kubfu: [
            'https://www.serebii.net/swordshield/pokemon/891.png',
            'https://www.serebii.net/Shiny/SWSH/891.png'
        ],
        urshifu_single_strike: [
            'https://www.serebii.net/swordshield/pokemon/892.png',
            'https://www.serebii.net/Shiny/SWSH/892.png'
        ],
        urshifu_rapid_strike: [
            'https://www.serebii.net/swordshield/pokemon/892-r.png',
            'https://www.serebii.net/Shiny/SWSH/892-r.png'
        ],
        zarude: [
            'https://www.serebii.net/swordshield/pokemon/893.png',
            'https://www.serebii.net/Shiny/SWSH/893.png'
        ],
        regieleki: [
            'https://www.serebii.net/swordshield/pokemon/894.png',
            'https://www.serebii.net/Shiny/SWSH/894.png'
        ],
        regidrago: [
            'https://www.serebii.net/swordshield/pokemon/895.png',
            'https://www.serebii.net/Shiny/SWSH/895.png'
        ],
        glastrier: [
            'https://www.serebii.net/swordshield/pokemon/896.png',
            'https://www.serebii.net/Shiny/SWSH/896.png'
        ],
        spectrier: [
            'https://www.serebii.net/swordshield/pokemon/897.png',
            'https://www.serebii.net/Shiny/SWSH/897.png'
        ],
        calyrex: [
            'https://www.serebii.net/swordshield/pokemon/898.png',
            'https://www.serebii.net/Shiny/SWSH/898.png'
        ]
        


        
    };

    async function getPokemonData(pokemonId) {
        const response = await fetch(`https://pokeapi.co/api/v2/pokemon/${pokemonId}`);
        const pokemon = await response.json();

        const speciesResponse = await fetch(pokemon.species.url);
        const species = await speciesResponse.json();

        const descriptionEntry = species.flavor_text_entries.find(entry => entry.language.name === 'es' && entry.version.name === 'sword');

        const images = [
            pokemon.sprites.front_default, 
            pokemon.sprites.other['official-artwork'].front_default,
            ...(shinyImages[pokemon.name.toLowerCase()] || [])
        ];

        return {
            name: pokemon.name,
            type: pokemon.types.map(typeInfo => typeInfo.type.name).join(', '),
            description: descriptionEntry ? descriptionEntry.flavor_text : 'Descripción no disponible',
            images: images
        };
    }

    async function loadGalarPokemonData() {
        const promises = [];
        for (let i = 810; i <= 898; i++) {
            promises.push(getPokemonData(i));
        }
        const results = await Promise.all(promises);
        
        const boxes = [];
        while (results.length) {
            boxes.push(results.splice(0, 24));
        }
        pokemonData = boxes;

        loadBox(currentBox);
    }

    function loadBox(boxNumber) {
        pokemonGrid.innerHTML = '';
        const boxData = pokemonData[boxNumber - 1];
        boxData.forEach(pokemon => {
            const box = document.createElement('div');
            box.classList.add('pokemon-box', `type-${pokemon.type.split(', ')[0]}`);
            box.setAttribute('data-pokemon', pokemon.name);
            box.setAttribute('data-description', pokemon.description);
            box.setAttribute('data-images', pokemon.images.join(','));

            const img = document.createElement('img');
            img.src = pokemon.images[0]; 
            img.alt = pokemon.name;
            box.appendChild(img);
            pokemonGrid.appendChild(box);

            box.addEventListener('click', () => {
                pokemonNameElem.textContent = pokemon.name;
                pokemonDescriptionElem.textContent = pokemon.description;
                pokemonImageMain.src = pokemon.images[1]; 
                pokemonImageSmall.src = pokemon.images[0]; 

                extraImagesContainer.innerHTML = '';
                pokemon.images.slice(2).forEach(image => {
                    const imgElement = document.createElement('img');
                    imgElement.src = image;
                    extraImagesContainer.appendChild(imgElement);
                });

                detailsPanel.style.display = 'block';
            });
        });

        
        paginationIndicator.textContent = `${boxNumber}/${pokemonData.length}`;
    }

    closeBtn.addEventListener('click', () => {
        detailsPanel.style.display = 'none';
    });

    leftArrow.addEventListener('click', () => {
        if (currentBox > 1) {
            currentBox--;
            loadBox(currentBox);
        }
    });

    rightArrow.addEventListener('click', () => {
        if (currentBox < pokemonData.length) {
            currentBox++;
            loadBox(currentBox);
        }
    });

    document.addEventListener('keydown', (event) => {
        if (event.key === 'ArrowLeft' || event.keyCode === 37) {
            if (currentBox > 1) {
                currentBox--;
                loadBox(currentBox);
            }
        } else if (event.key === 'ArrowRight' || event.keyCode === 39) {
            if (currentBox < pokemonData.length) {
                currentBox++;
                loadBox(currentBox);
            }
        }
    });

    loadGalarPokemonData();
    function handleIconClick(url) {
    window.location.href = url;
}
});

 